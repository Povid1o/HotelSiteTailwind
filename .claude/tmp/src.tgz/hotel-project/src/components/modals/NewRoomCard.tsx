import React, { useState, useCallback, useEffect, useRef } from 'react';
import PhotoSelector from '../text_inputs/PhotoSelector';
import PriceList from '../text_inputs/PriceList';
import DescriptionInput from '../text_inputs/DescriptionInput';
import MultiInputField from '../text_inputs/MultiInputField';
import Button from '../text_inputs/Button';
import { MdModeEdit } from "react-icons/md";

import "../styles/newRoomCard.css"; 

const NewRoomCard = ({
  roomName,
  photos,
  properties,
  conviniences,
  description,
  prices,
  checkIn,
  checkOut,
  notes,
  onDataChange = () => {}
}) => {
  // Локальные состояния для отслеживания изменений
  const [localName, setLocalName] = useState(roomName);
  const [changeNameState, setChangeNameState] = useState(false);
  const [localPhotos, setLocalPhotos] = useState(photos);
  const [localProperties, setLocalProperties] = useState(properties);
  const [localConviniences, setLocalConviniences] = useState(conviniences);
  const [localDescription, setLocalDescription] = useState(description);
  const [localPrices, setLocalPrices] = useState(prices);
  const [localCheckIn, setLocalCheckIn] = useState(checkIn);
  const [localCheckOut, setLocalCheckOut] = useState(checkOut);
  const [localNotes, setLocalNotes] = useState(notes);

  // ✅ КРИТИЧНО: Синхронизируем локальное состояние с props после обновлений из backend
  useEffect(() => {
    console.log('NewRoomCard: syncing photos from props', photos);
    setLocalPhotos(photos);
  }, [photos]);

  useEffect(() => {
    setLocalName(roomName);
  }, [roomName]);

  useEffect(() => {
    setLocalProperties(properties);
  }, [properties]);

  useEffect(() => {
    setLocalConviniences(conviniences);
  }, [conviniences]);

  useEffect(() => {
    setLocalDescription(description);
  }, [description]);

  useEffect(() => {
    setLocalPrices(prices);
  }, [prices]);

  useEffect(() => {
    setLocalCheckIn(checkIn);
  }, [checkIn]);

  useEffect(() => {
    setLocalCheckOut(checkOut);
  }, [checkOut]);

  useEffect(() => {
    setLocalNotes(notes);
  }, [notes]);

  // ✅ Debounce timer для батчинга изменений
  const debounceTimerRef = useRef<NodeJS.Timeout | null>(null);
  const pendingChangesRef = useRef<any>({});
  const onDataChangeRef = useRef(onDataChange);
  const latestDataRef = useRef<any>({});
  onDataChangeRef.current = onDataChange;
  latestDataRef.current = {
    name: localName,
    images: localPhotos,
    properties: localProperties,
    conviniences: localConviniences,
    description: localDescription,
    price: localPrices,
    checkStandart: { checkIn: localCheckIn, checkOut: localCheckOut },
    notes: localNotes,
  };

  // Closing the editor must not discard an edit still inside the debounce window.
  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
        onDataChangeRef.current({ ...latestDataRef.current, ...pendingChangesRef.current });
        pendingChangesRef.current = {};
        debounceTimerRef.current = null;
      }
    };
  }, []);

  // ✅ Мемоизированная функция для батчинга изменений
  const updateRoomData = useCallback((updatedData) => {
    // Накапливаем изменения
    pendingChangesRef.current = {
      ...pendingChangesRef.current,
      ...updatedData
    };

    // Очищаем предыдущий таймер
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    // Устанавливаем новый таймер (500ms debounce)
    debounceTimerRef.current = setTimeout(() => {
      const newData = {
        name: localName,
        images: localPhotos,
        properties: localProperties,
        conviniences: localConviniences,
        description: localDescription,
        price: localPrices,
        checkStandart: {
          checkIn: localCheckIn,
          checkOut: localCheckOut
        },
        notes: localNotes,
        ...pendingChangesRef.current // ✅ Применяем накопленные изменения
      };
      
      console.log('🔄 NewRoomCard: Sending batched changes:', Object.keys(pendingChangesRef.current));
      onDataChange(newData);
      
      // Очищаем накопленные изменения
      pendingChangesRef.current = {};
      debounceTimerRef.current = null;
    }, 500); // ✅ 500ms задержка для батчинга
  }, [localName, localPhotos, localProperties, localConviniences, localDescription, localPrices, localCheckIn, localCheckOut, localNotes, onDataChange]);

  // Мемоизированные обработчики для каждого поля
  const handleNameSave = useCallback((newName) => {
    setLocalName(newName);
    setChangeNameState(false);
    updateRoomData({ name: newName });
  }, [updateRoomData]);

  const handlePhotosChange = useCallback((newPhotos) => {
    console.log('Photos changed in NewRoomCard:', newPhotos);
    setLocalPhotos(newPhotos);
    updateRoomData({ images: newPhotos });
  }, [updateRoomData]);

  const handlePropertiesChange = useCallback((newProperties) => {
    setLocalProperties(newProperties);
    updateRoomData({ properties: newProperties });
  }, [updateRoomData]);

  const handleConviniencesChange = useCallback((newConviniences) => {
    setLocalConviniences(newConviniences);
    updateRoomData({ conviniences: newConviniences });
  }, [updateRoomData]);

  const handleDescriptionChange = useCallback((newDescription) => {
    setLocalDescription(newDescription);
    updateRoomData({ description: newDescription });
  }, [updateRoomData]);

  const handlePricesChange = useCallback((newPrices) => {
    setLocalPrices(newPrices);
    updateRoomData({ price: newPrices });
  }, [updateRoomData]);

  const handleCheckInChange = useCallback((newCheckIn) => {
    setLocalCheckIn(newCheckIn);
    updateRoomData({ checkStandart: { checkIn: newCheckIn, checkOut: localCheckOut } });
  }, [updateRoomData, localCheckOut]);

  const handleCheckOutChange = useCallback((newCheckOut) => {
    setLocalCheckOut(newCheckOut);
    updateRoomData({ checkStandart: { checkIn: localCheckIn, checkOut: newCheckOut } });
  }, [updateRoomData, localCheckIn]);

  const handleNotesChange = useCallback((newNotes) => {
    setLocalNotes(newNotes);
    updateRoomData({ notes: newNotes });
  }, [updateRoomData]);

  return (
    <div className="relative flex w-full flex-col bg-[#FBF8EF] rounded-lg overflow-x-hidden">
      <header className="flex min-h-[70px] items-center justify-between border-b border-solid border-b-[#F5EFDB] px-4 py-3 sm:px-10">
        <div className="flex min-w-0 flex-wrap items-center gap-4 text-[#201A09]">
          {!changeNameState ? (
            <>
              <h1 className="text-[#201A09] text-lg font-bold leading-tight tracking-[-0.015em] break-words">{localName}</h1>
              <label>
                <Button
                  icon={<MdModeEdit className='h-[20px] w-[20px]' />}
                  func={() => setChangeNameState(true)}
                />
              </label>
            </>
          ) : (
            <DescriptionInput
              inputField={true}
              horizontal={true}
              text={localName}
              onSave={handleNameSave}
            />
          )}
        </div>
      </header>

      <div className="flex flex-1 justify-center py-5 sm:px-10 lg:px-40">
        <div className="layout-content-container flex min-w-0 max-w-[960px] flex-1 flex-col">
          <PhotoSelector
            photos={localPhotos}
            header={"Фото Номера"}
            onPhotosChange={handlePhotosChange}
            withSlider={true}
          />
          
          <div className="flex justify-stretch">
            <div className="flex flex-1 flex-wrap justify-around gap-x-10 gap-y-2 py-3 sm:px-4">
              <div className='flex flex-col'>
                <h1 className="first-header">Свойства</h1>
                <MultiInputField
                  initialValues={localProperties}
                  onSave={handlePropertiesChange}
                />
              </div>
              <div className='flex flex-col'>
                <h1 className="first-header">Удобства</h1>
                <MultiInputField
                  initialValues={localConviniences}
                  onSave={handleConviniencesChange}
                />
              </div>
            </div>
          </div>

          <h1 className="first-header">Описание</h1>
          <DescriptionInput
            text={localDescription}
            onSave={handleDescriptionChange}
          />

          <h1 className="first-header">Цены</h1>
          <PriceList
            globalPrices={localPrices}
            onSave={handlePricesChange}
          />

          <h1 className="first-header px-4">Правила размещения</h1>
          <div className="flex flex-row flex-wrap gap-4">
            <div className="flex-1 min-w-[200px]">
              <h2 className="second-header sm:px-6">Заезд</h2>
              <DescriptionInput
                inputField={true}
                text={localCheckIn}
                onSave={handleCheckInChange}
              />
            </div>
            <div className="flex-1 min-w-[200px]">
              <h2 className="second-header sm:px-6">Выезд</h2>
              <DescriptionInput
                inputField={true}
                text={localCheckOut}
                onSave={handleCheckOutChange}
              />
            </div>
            <div className="flex-1 min-w-[200px] max-w-[350px]">
              <h2 className="second-header sm:px-4">Примечания</h2>
              <MultiInputField
                initialValues={localNotes}
                onSave={handleNotesChange}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewRoomCard;
